# Iqbal Agentic AI — Awakening of Khudi

A **working educational MVP**, inspired by Dr Allama Muhammad Iqbal's philosophical themes. It includes a FastAPI backend, a Vite-powered responsive web interface, five curated lesson modules, source-labelled Qur'an/Hadith excerpts, and basic API tests.

> **Important:** This is not yet an autonomous agent or LLM chat system. The `/chat` endpoint returns the selected lesson and reflection rather than generating personalised answers. No automatic deployment, authentication, private journal storage, religious fatwas or external actions are included. The Phase 2 curriculum is in `docs/PHASE_2_LESSONS.md`.

## Run locally

Requirements: Python 3.10+ and Node.js 20+.

```bash
# Terminal 1, from repository root
python -m venv .venv
source .venv/bin/activate  # Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -r backend/requirements.txt
uvicorn backend.main:app --reload

# Terminal 2
cd frontend
npm install
npm run dev
```

Open `http://localhost:5173`. API documentation is at `http://localhost:8000/docs`.

## Test

```bash
python -m pytest -q
cd frontend && npm run build
```

## Configuration and deployment

Set `VITE_API_URL` to the deployed API origin when building the frontend. Adjust the FastAPI CORS allowlist for your actual production frontend domain. Deploy frontend and backend separately using a supported host. Add rate limiting, auth, structured logging, content review, accessibility testing and privacy controls before public release.

## Sources and editorial policy

Qur'an verses and Hadith excerpts are identified by chapter/verse or collection/number. The English translations are concise educational renderings; confirm against an approved edition before publication. Do not misattribute Iqbal quotations. His copyrighted translations/editions should not be ingested without permission. This repository intentionally contains **no unverified Iqbal quotes**. Philosophical summaries are labelled as interpretations. Review Arabic vocalisation, transliteration and citations with qualified editors prior to production.

## GitHub upload

Create a new empty GitHub repository, extract this ZIP, then run:

```bash
git init
git add .
git commit -m "Initial Iqbal AI educational MVP"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/iqbal-agentic-ai.git
git push -u origin main
```

Replace `YOUR_USERNAME` with your own GitHub username. The remote repository must exist and you must be authenticated.

## Licence

MIT licence applies to original project code and curriculum. Qur'anic text and Hadith excerpts are traditional source material; translations and editorial resources may have separate rights.
