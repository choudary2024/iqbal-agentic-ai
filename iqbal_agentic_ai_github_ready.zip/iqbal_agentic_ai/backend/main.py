from pathlib import Path
import json
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

ROOT = Path(__file__).parent
DATA = json.loads((ROOT / 'data' / 'modules.json').read_text(encoding='utf-8'))
app = FastAPI(title='Iqbal Agentic AI', version='0.1.0')
app.add_middleware(CORSMiddleware, allow_origins=['http://localhost:5173','http://127.0.0.1:5173'], allow_methods=['GET','POST'], allow_headers=['Content-Type'])

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=2000)
    mode: str = 'khudi'

@app.get('/health')
def health(): return {'status':'ok'}

@app.get('/modules')
def modules(): return DATA

@app.post('/chat')
def chat(request: ChatRequest):
    module = next((x for x in DATA if x['id'] == request.mode), None)
    if not module: raise HTTPException(400, 'Unknown mode')
    return {'mode':module['id'], 'message':request.message, 'lesson':module['summary'], 'quran':module['quran'], 'hadith':module.get('hadith'), 'reflection':module['reflection'], 'action':module['action'], 'note':'Educational, source-grounded prototype. No LLM or autonomous execution is connected.'}
