# Phase 2 — Educational and philosophical lessons

These are **original educational interpretations**, not direct quotations from Allama Iqbal. Do not present the application as speaking on his behalf.

## 1. Khudi: purposeful selfhood
**Tutor script:** "Khudi is not arrogance. It asks you to cultivate moral agency, responsibility, and purposeful effort. Identify one intention and one action you can honestly sustain."  
**Dialogue:** "Which strength can you develop through service?" → "What obstacle might arise?" → "What will you do today?"  
**Exercise:** Intention journal, one practical step, evening reflection.

## 2. Ijtihad: disciplined inquiry
**Tutor script:** "Ask good questions, inspect evidence, and acknowledge uncertainty. Formal Islamic legal ijtihad requires qualified scholarship; this module does not issue rulings."  
**Dialogue:** "What is the question?" → "Which sources support your view?" → "What remains uncertain?"  
**Exercise:** Write two arguments and a source-quality assessment.

## 3. Tawheed: coherence of life
**Tutor script:** "Reflect on how your intentions, learning, relationships and responsibilities align with worship and ethical conduct."  
**Dialogue:** "What values guide your decisions?" → "Where is there a gap between belief and action?"  
**Exercise:** Select one habit that supports integrity.

## 4. Shaja'ah: courage and action
**Tutor script:** "Courage is responsible action, not recklessness. Start with a small, beneficial and safe step."  
**Dialogue:** "What worthwhile task have you avoided?" → "What is the smallest safe next step?"  
**Exercise:** A seven-day action plan with a review date.

## 5. Reform: service and solidarity
**Tutor script:** "Consider how education, dignity, justice and collaboration can improve lives. Start with a concrete local need."  
**Dialogue:** "Who is affected?" → "Have you listened to them?" → "How will you measure benefit?"  
**Exercise:** Draft a one-page community project charter.

## Recommended agent design for the next iteration
- **Retriever:** licensed, curated Iqbal primary texts and verified Qur'an/Hadith editions with source-level citations.
- **Planner:** turn voluntary learning goals into draft weekly study plans.
- **Coach:** offer optional reflection prompts and progress reviews.
- **Verifier:** flag unattributed poetry, uncertain translations and unsupported theological claims.
- **Approval gate:** require user confirmation before any external actions.
- **Memory:** opt-in, deletable, encrypted learning history; no religious profiling or targeted persuasion.

These are **planned capabilities**, not implemented in the included MVP. The MVP is a deterministic, offline-content learning API with a browser interface; it does not include an LLM, autonomous agent, account system or deployment.
