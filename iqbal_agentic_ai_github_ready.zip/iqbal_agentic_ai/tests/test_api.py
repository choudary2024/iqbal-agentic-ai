from fastapi.testclient import TestClient
from backend.main import app
client = TestClient(app)
def test_health(): assert client.get('/health').json()['status'] == 'ok'
def test_modules(): assert len(client.get('/modules').json()) == 5
def test_chat(): assert client.post('/chat', json={'message':'How do I begin?', 'mode':'khudi'}).status_code == 200
def test_invalid_mode(): assert client.post('/chat', json={'message':'Hello', 'mode':'unknown'}).status_code == 400
