const API = import.meta.env.VITE_API_URL || 'http://localhost:8000';
const mode = document.querySelector('#mode');
const lesson = document.querySelector('#lesson');
const result = document.querySelector('#result');
let modules = [];
function node(tag, text, className) { const e = document.createElement(tag); e.textContent = text; if(className)e.className=className; return e; }
function add(container, tag, text, className) { container.append(node(tag,text,className)); }
function showSource(container, title, source) { if(!source)return; const section=node('div','','entry'); add(section,'h3',title);add(section,'p',source.arabic,'arabic');add(section,'p',source.transliteration);add(section,'p',source.english);add(section,'p',source.reference,'source');container.append(section); }
function renderLesson(m) { lesson.replaceChildren();add(lesson,'h2',m.title);add(lesson,'p',m.summary);showSource(lesson,'Qur’an',m.quran);showSource(lesson,'Authentic Hadith',m.hadith);add(lesson,'h3','Reflect');add(lesson,'p',m.reflection);add(lesson,'h3','Act');add(lesson,'p',m.action); }
async function init(){try{const response=await fetch(`${API}/modules`);if(!response.ok)throw Error('API unavailable');modules=await response.json();for(const m of modules){const opt=document.createElement('option');opt.value=m.id;opt.textContent=m.title;mode.append(opt);}renderLesson(modules[0]);}catch(e){add(lesson,'p','Unable to load modules. Start the backend and refresh.');}}
mode.addEventListener('change',()=>{renderLesson(modules.find(m=>m.id===mode.value));result.replaceChildren();});
document.querySelector('#ask').addEventListener('click',async()=>{result.replaceChildren();const message=document.querySelector('#message').value.trim();if(!message){add(result,'p','Enter a question or reflection first.');return;}try{const response=await fetch(`${API}/chat`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message,mode:mode.value})});if(!response.ok)throw Error('Request failed');const data=await response.json();add(result,'h2','Your learning pathway');add(result,'p',data.lesson);add(result,'p',`Reflection: ${data.reflection}`);add(result,'p',`Suggested action: ${data.action}`);add(result,'p',data.note,'source');}catch(e){add(result,'p','Unable to reach the backend.');}});
init();
